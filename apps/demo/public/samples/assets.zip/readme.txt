Asset bundle manifest
- map.png
- beacon.ts
- log.csv
